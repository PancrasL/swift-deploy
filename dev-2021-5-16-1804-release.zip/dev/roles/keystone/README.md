Keystone
=========

Install openstack keystone

Requirements
------------

System should be Ubuntu(>=16.04)

Role Variables
--------------

> edit below variables at defaults/main.yml or vars/main.yml

- keystone_db_password → your keystone database password
- keystone_admin_password → your keystone root password

License
-------

BSD

Probiotic@[daqu](https://github.com/Daqu)
------------------
