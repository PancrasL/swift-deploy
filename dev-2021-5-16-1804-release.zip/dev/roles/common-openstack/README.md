common-openstack
=========

Install openstack environment

Requirements
------------

System should be Ubuntu(>=16.04)

Role Variables
--------------

> edit below variables at defaults/main.yml or vars/main.yml

- ubuntu_version_name → eg: xenial
- openstack_version_name → eg: queens

License
-------

BSD

Probiotic@[daqu](https://github.com/Daqu)
------------------